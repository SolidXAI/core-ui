"use client";

import { useInitiateChangePasswordMutation } from "@/redux/api/authApi";
import { useFormik } from "formik";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "primereact/button";
import { InputText } from "primereact/inputtext";
import { Message } from "primereact/message";
import { Toast } from "primereact/toast";
import { useContext, useEffect, useRef } from "react";
import * as Yup from "yup";
import { LayoutContext } from "../layout/context/layoutcontext";
import { useLazyGetAuthSettingsQuery } from "@/redux/api/solidSettingsApi";


const SolidForgotPassword = () => {
    const [trigger, { data: solidSettingsData }] = useLazyGetAuthSettingsQuery()
    useEffect(() => {
        trigger("") // Fetch settings on mount
    }, [trigger])
    const { layoutConfig } = useContext(LayoutContext);
    const { authLayout } = layoutConfig;
    const toast = useRef<Toast>(null);
    const router = useRouter();
    const showToast = (severity: "success" | "error", summary: string, detail: string) => {
        toast.current?.show({
            severity,
            summary,
            detail,
            life: 3000,
        });
    };
    const [initiateChangePassword] = useInitiateChangePasswordMutation();
    const validationSchema = Yup.object({
        email: Yup.string()
            .email('Invalid email format')
            .required('Email is required'),
    });
    function maskEmail(email: string) {
        const [localPart, domain] = email.split('@');
        const maskedLocal = localPart.slice(0, 3) + '*'.repeat(localPart.length - 3);
        const maskedDomain = domain.slice(-8).padStart(domain.length, '*');
        return `${maskedLocal}@${maskedDomain}`;
    }

    const formik = useFormik({
        initialValues: {
            email: "",
        },
        validationSchema,
        onSubmit: async (values) => {
            try {
                const payload = {
                    email: values.email,
                };
                const response = await initiateChangePassword(payload).unwrap();
                if (response?.statusCode === 200) {
                    const email = response?.data?.data?.user?.email;
                    const maskedEmail = maskEmail(email);
                    router.push(`/auth/initiate-forgot-password-thank-you?email=${maskedEmail}`)
                } else (
                    showToast("error", "Login Error", response.error)
                )
            } catch (err: any) {
                console.log("Error", err);
                showToast("error", "Login Error", err?.data ? err?.data?.message : "Something Went Wrong");
            }
        },
    });

    const isFormFieldValid = (formik: any, fieldName: string) =>
        formik.touched[fieldName] && formik.errors[fieldName];

    return (
        <>
            <Toast ref={toast} />
            <div className={`auth-container ${solidSettingsData?.data?.authPagesLayout === 'center' ? 'center' : 'side'}`}>
                {solidSettingsData?.data?.authPagesLayout === 'center' &&
                    <div className="flex justify-content-center">
                        <div className="solid-logo flex align-items-center gap-3">
                            <img
                                alt="solid logo"
                                src={'/images/SS-Logo-1 1.png'}
                                className="position-relative img-fluid"
                            />
                            <div>
                                <p className="solid-logo-title">
                                    Solid<br />Starters
                                </p>
                            </div>
                        </div>
                    </div>
                }
                <h2 className={`solid-auth-title ${solidSettingsData?.data?.authPagesLayout === 'center' ? 'text-center' : 'text-left'}`}>Forgot Password</h2>
                {/* <p className="solid-auth-subtitle text-sm">By continuing, you agree to the <Link href={'#'}>Terms of Service</Link> and acknowledge you’ve read our  <Link href={'#'}>Privacy Policy.</Link> </p> */}
                <form onSubmit={formik.handleSubmit}>
                    <div className="flex flex-column gap-2">
                        <label htmlFor="email" className="solid-auth-input-label">Username or Email</label>
                        <InputText
                            id="email"
                            name="email"
                            placeholder="Email ID"
                            value={formik.values.email}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                        />
                        {isFormFieldValid(formik, "email") && <Message
                            className="text-red-500 text-sm"
                            severity="error"
                            text={formik?.errors?.email?.toString()}
                        />}
                    </div>
                    <div className="mt-4">
                        <Button className="w-full font-light auth-submit-button" label="Send OTP" disabled={formik.isSubmitting} loading={formik.isSubmitting} />
                    </div>
                </form>
            </div>
            <div className="text-center mt-5">
                <div className="text-sm text-400 secondary-dark-color">
                    {'<'} Back to <Link className="font-bold" href="/auth/login">Sign In</Link>
                </div>
            </div>
        </>
    );
};

export default SolidForgotPassword;