"use client";

import { Form, Formik } from "formik";
import { signIn } from "next-auth/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "primereact/button";
import { InputOtp } from "primereact/inputotp";
import { Message } from "primereact/message";
import { Toast } from "primereact/toast";
import { useContext, useRef, useState } from "react";
import * as Yup from "yup";
import { LayoutContext } from "../layout/context/layoutcontext";


const SolidOTPVerify = () => {
    const { layoutConfig } = useContext(LayoutContext);
    const { authLayout } = layoutConfig;
    const [otp, setOTP] = useState<number | any>();

    const toast = useRef<Toast>(null);
    const router = useRouter();

    const [password, setPassword] = useState('');
    const [checked, setChecked] = useState<boolean>(false);

    const validationSchema = Yup.object({
        email: Yup.string()
            .email("Invalid email address")
            .required("Email is required"),
    });

    const showToast = (severity: "success" | "error", summary: string, detail: string) => {
        toast.current?.show({
            severity,
            summary,
            detail,
            life: 3000,
        });
    };

    const isFormFieldValid = (formik: any, fieldName: string) =>
        formik.touched[fieldName] && formik.errors[fieldName];

    return (
        <>
            <Toast ref={toast} />
            <div className={`auth-container ${authLayout === 'Center' ? 'center' : 'side'}`} style={{ minWidth: 480 }}>
            {authLayout === 'Center' &&
                    <div className="flex justify-content-center">
                        <div className="solid-logo flex align-items-center gap-3">
                            <img
                                alt="solid logo"
                                src={'/images/SS-Logo-1 1.png'}
                                className="position-relative img-fluid"
                            />
                            <div>
                                <p className="solid-logo-title">
                                    Solid<br />Starters
                                </p>
                            </div>
                        </div>
                    </div>
                }
                <h2 className={`solid-auth-title ${authLayout === 'Center' ? 'text-center' : 'text-left'}`}>OTP Verification</h2>
                <p className="solid-auth-subtitle text-sm">
                    Please enter the OTP sent to your email to complete verification
                </p>
                <>
                    <Formik
                        initialValues={{
                            email: "",
                            password: "",
                        }}
                        validationSchema={validationSchema}
                        onSubmit={async (values) => {
                            // Handle form submission
                            const email = values.email;
                            const password = values.password;

                            const response = await signIn("credentials", {
                                redirect: false,
                                email,
                                password,
                            });
                            if (response?.error) {
                                showToast("error", "Login Error", response.error);
                            } else {
                                showToast("success", "Login Success", "Redirecting to dashboard...");
                                router.push("/admin/core/solid-core/user/list");
                            }

                        }}
                    >
                        {(formik) => (
                            <Form>
                                <div className="flex flex-column gap-2 px-3">
                                    <label htmlFor="email" className="solid-auth-input-label">Enter OTP</label>
                                    <InputOtp value={otp} onChange={(e) => setOTP(e.value)} length={6} style={{ width: '100%' }} />
                                    {isFormFieldValid(formik, "email") && <Message
                                        className="text-red-500 text-sm"
                                        severity="error"
                                        text={formik?.errors?.email?.toString()}
                                    />}
                                    <div className="flex align-items-center justify-content-between">
                                        <Button type="button" icon='pi pi-refresh' iconPos="left" link label="Resend Code" className="px-0 text-sm font-normal" />
                                        <p className="m-0 text-sm text-color">
                                            Time left: 00:28
                                        </p>
                                    </div>
                                </div>
                                <div className="mt-4">
                                    <Button type="submit" className="w-full font-light auth-submit-button" label="Verify"  disabled={formik.isSubmitting} loading={formik.isSubmitting}/>
                                </div>
                            </Form>
                        )}
                    </Formik>
                </>
            </div>
            <div className="text-center mt-5">
                <div className="text-sm text-400 secondary-dark-color">
                    {'<'} Back to <Link className="font-bold" href="/auth/login">Sign In</Link>
                </div>
            </div>
        </>
    );
};

export default SolidOTPVerify;